#!/usr/bin/python3.1
import cgi  

print("Content-type: text/html\r\n\r\n")
print("<title>Reply Page</title>")
f = open("../htdocs/history/test", "r")
f.close()
